TELEGRAM_TOKEN = '在這裡填入你的 Token'
TELEGRAM_CHAT_ID = '在這裡填入你的 Chat ID'
BYBIT_API_KEY = '你的Bybit API金鑰'
BYBIT_API_SECRET = '你的Bybit密鑰'
