from telegram_notifier import send_telegram_message

# SNR 自動交易主控式（翻倍特化版）
print("自動交易機器人啟動！")

# 這裡會包含你的自動調整槓桿、強幣篩選、分批出場、移動停利等完整邏輯
# ...
