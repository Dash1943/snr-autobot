#!/bin/bash
echo "安裝所需套件中..."
pip install -r requirements.txt
echo "完成！請使用 python3 main.py 啟動"
