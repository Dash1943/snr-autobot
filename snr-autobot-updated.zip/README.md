# SNR 翻倍特化版機器人

## 使用方式：
1. 填入 `config.py` 的 TOKEN 與金鑰
2. 執行安裝指令：

```bash
chmod +x install.sh
./install.sh
```

3. 啟動主程式：

```bash
python3 main.py
```

## 功能特色：
- 多週期突破確認
- 強幣篩選（Top Volume）
- 自動調整槓桿
- 分批出場與移動停利
- 風險控制與 Telegram 回報系統
